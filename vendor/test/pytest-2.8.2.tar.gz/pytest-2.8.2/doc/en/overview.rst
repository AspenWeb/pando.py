==================================================
Getting started basics
==================================================

.. toctree::
   :maxdepth: 2

   index
   getting-started
   usage
   goodpractises
   projects
   faq

