Cheroot is a highly-optimized, pure-python HTTP server


